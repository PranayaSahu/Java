package com.mindtree.service;

import java.util.List;

import com.mindtree.exception.ShoppingCartException;

public interface ApparelService {

	public List<Object> fetchAllApparel() throws ShoppingCartException;
}
