package com.mindtree.service;

import java.util.List;

import com.mindtree.dto.ShowCartDetailsDTO;
import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.Product;
import com.mindtree.model.User;

public interface CartService {

	boolean addToCart(List<Product> products, User userEmail, int quantity) throws ShoppingCartException;
	
	ShowCartDetailsDTO viewCart(String userEmail) throws ShoppingCartException;
	
	void removeProductFromCart(int productId, String userEmail) throws ShoppingCartException;
	
	void removeAllProductsFromCart(String userEmail) throws ShoppingCartException;
}
