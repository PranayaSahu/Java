package com.mindtree.service;

import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.User;

public interface UserService {

	public int checkIfUserAlreadyPresent(String email, String password) throws ShoppingCartException;
	public User fetchUserByEmail(String email) throws ShoppingCartException;
}
