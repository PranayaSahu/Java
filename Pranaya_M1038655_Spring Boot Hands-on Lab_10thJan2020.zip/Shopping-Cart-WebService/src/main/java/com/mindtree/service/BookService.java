package com.mindtree.service;

import java.util.List;

import com.mindtree.exception.ShoppingCartException;

public interface BookService {

	public List<Object> fetchAllBooks() throws ShoppingCartException;
}
