package com.mindtree.service;

import java.util.List;

import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.Product;

public interface ProductService {

	public Product fetchProductById(int productId) throws ShoppingCartException;
	public List<Product> fetchProductByName(String productName) throws ShoppingCartException;
	public void updateTheProductQuantity(Product product, int quantity) throws ShoppingCartException;
}
