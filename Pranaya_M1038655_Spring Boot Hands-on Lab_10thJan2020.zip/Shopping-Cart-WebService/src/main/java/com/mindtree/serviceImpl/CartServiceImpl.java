package com.mindtree.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.CartDao;
import com.mindtree.dto.ShowCartDetailsDTO;
import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.Apparel;
import com.mindtree.model.Book;
import com.mindtree.model.Cart;
import com.mindtree.model.Product;
import com.mindtree.model.User;
import com.mindtree.service.CartService;

@Service
public class CartServiceImpl implements CartService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CartServiceImpl.class);
	@Autowired
	private CartDao cartDao;

	private Map<Integer, Integer> productMap = new HashMap<Integer, Integer>();

	public boolean addToCart(List<Product> products, User user, int quantity) throws ShoppingCartException {
		LOGGER.trace("Enter addToCart Method.");
		LOGGER.info("Adding product in cart");
		double totalPrice = 0.0;
		boolean saved = false, productExist = false;
		Cart userCart = cartDao.findCartDetailsByEmail(user.getEmailAddress());
		if (userCart != null && userCart.getCartId() > 0) {
			LOGGER.debug("User cart already present. Updating the cart");
			totalPrice = userCart.getTotalPrice();
			List<Product> listOfProduct = userCart.getProducts();
			updateProductMap(listOfProduct, quantity);
			for (Product product : products) {
				totalPrice = totalPrice + (product.getProductPrice() * quantity);
				if (productMap != null && productMap.containsKey(product.getProductId())) {
					productExist = true;
				} else {
					productExist = false;
				}
				if (!productExist) {
					listOfProduct.add(product);
				}
			}
			userCart.setProducts(listOfProduct);
			userCart.setTotalPrice(totalPrice);
			try {
				cartDao.save(userCart);
				saved = true;
				if (productMap.containsKey(products.get(0).getProductId())) {
					productMap.replace(products.get(0).getProductId(),
							productMap.get(products.get(0).getProductId()) + quantity);
				} else {
					productMap.put(products.get(0).getProductId(), quantity);
				}
			} catch (Exception e) {
				LOGGER.error("Can not update the cart for user : " + user.getEmailAddress());
				saved = false;
				throw new ShoppingCartException("Can not update the cart for user");
			}
		} else {
			LOGGER.info("addToCart for new User cart");
			userCart = new Cart();
			userCart.setProducts(products);
			for (Product product : products) {
				totalPrice = totalPrice + (product.getProductPrice() * quantity);
			}
			userCart.setTotalPrice(totalPrice);
			userCart.setUser(user);
			try {
				cartDao.save(userCart);
				saved = true;
				updateProductMap(products, quantity);
			} catch (Exception e) {
				LOGGER.error("Can not save the product in the user cart");
				saved = false;
				throw new ShoppingCartException("Can not save the product in the user cart");
			}
		}
		LOGGER.trace("Exit addToCart Method.");
		return saved;
	}

	private void updateProductMap(List<Product> listOfProduct, int quantity) {
		for (Product product : listOfProduct) {
			if (productMap != null && !productMap.containsKey(product.getProductId()))
				productMap.put(product.getProductId(), quantity);
		}
	}

	public ShowCartDetailsDTO viewCart(String userEmail) throws ShoppingCartException {
		LOGGER.info("viewCart for user : " + userEmail);
		ShowCartDetailsDTO cartDetails = new ShowCartDetailsDTO();
		List<Product> lop = new ArrayList<Product>();
		Product p1 = null;
		try {
			Cart c = cartDao.findCartDetailsByEmail(userEmail);
			cartDetails.setUserEmail(userEmail);
			if (c != null && c.getProducts() != null && !c.getProducts().isEmpty()) {
				for (Product p : c.getProducts()) {
					if (productMap.containsKey(p.getProductId())) {
						if (p instanceof Book) {
							p1 = new Book(p.getProductId(), p.getProductName(), p.getProductPrice(),
									productMap.get(p.getProductId()), ((Book) p).getBookGenre(),
									((Book) p).getBookAuthor(), ((Book) p).getBookPublications());
						} else if (p instanceof Apparel) {
							p1 = new Apparel(p.getProductId(), p.getProductName(), p.getProductPrice(),
									productMap.get(p.getProductId()), ((Apparel) p).getApparelType(),
									((Apparel) p).getApparelBrand(), ((Apparel) p).getApparelDesign());
						}
						lop.add(p1);
					}
				}
				cartDetails.setListOfProducts(lop);
				cartDetails.setTotalAmountDue(c.getTotalPrice());
			}
		} catch (Exception e) {
			LOGGER.error("Cart does not exist for user : " + userEmail);
			throw new ShoppingCartException("Cannot find the cart for user details");
		}
		return cartDetails;
	}

	public void removeProductFromCart(int productId, String userEmail) throws ShoppingCartException {
		LOGGER.info("removeProductFromCart for user : " + userEmail);
		try {
			int i = 0;
			double value = 0;
			Cart c = cartDao.findCartDetailsByEmail(userEmail);
			if (c != null) {
				for (Product product : c.getProducts()) {
					if (product.getProductId() == productId) {
						value = product.getProductPrice() * productMap.get(productId);
						c.getProducts().remove(i);
						break;
					}
					i++;
				}
				c.setTotalPrice(c.getTotalPrice() - value);
				cartDao.saveAndFlush(c);
				if (productMap != null && productMap.containsKey(productId)) {
					productMap.remove(productId);
				}
			}
		} catch (Exception sce) {
			LOGGER.error("User cart cannot be found for user: " + userEmail);
			throw new ShoppingCartException("User cart cannot be found");
		}

	}

	public void removeAllProductsFromCart(String userEmail) throws ShoppingCartException {
		LOGGER.info("removeAllProductsFromCart for user : " + userEmail);
		List<Product> lop = new ArrayList<Product>();
		try {
			Cart userCart = cartDao.findCartDetailsByEmail(userEmail);
			if (userCart != null && userCart.getProducts() != null && !userCart.getProducts().isEmpty()) {
				lop = userCart.getProducts();
				userCart.getProducts().removeAll(userCart.getProducts());
			}
			cartDao.saveAndFlush(userCart);
			for (Product p : lop) {
				if (productMap != null && productMap.containsKey(p.getProductId())) {
					productMap.remove(p.getProductId());
				}
			}
		} catch (Exception e) {
			LOGGER.error("Products can not be deleted from the cart for user : " + userEmail);
			throw new ShoppingCartException("Products can not be deleted from the cart");
		}
	}
}
