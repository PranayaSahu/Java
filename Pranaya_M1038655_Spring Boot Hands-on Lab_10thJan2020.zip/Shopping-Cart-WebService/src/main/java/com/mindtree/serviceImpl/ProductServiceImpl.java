package com.mindtree.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.ProductDao;
import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.Product;
import com.mindtree.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductServiceImpl.class);
	@Autowired
	private ProductDao productDao;

	public Product fetchProductById(int productId) throws ShoppingCartException {
		LOGGER.debug("Enter fetchProductById method.");
		LOGGER.info("Fetch product by id :" + productId);
		Product product = null;
		try {
			Optional<Product> prod = productDao.findById(productId);
			if (prod != null && prod.get() != null) {
				product = prod.get();
			}
		} catch (Exception e) {
			LOGGER.error("Product not found.");
			throw new ShoppingCartException("Product not found.");
		}
		LOGGER.debug("Exit fetchProductById method.");
		return product;
	}

	public List<Product> fetchProductByName(String productName) throws ShoppingCartException {
		LOGGER.trace("Enter fetchProductByName method.");
		LOGGER.info("Fetch product by name :" + productName);
		List<Product> productList = null;
		try {
			productList = productDao.findByProductName(productName);
		} catch (Exception e) {
			LOGGER.error("Product not found.");
			throw new ShoppingCartException("Product not found.");
		}
		LOGGER.trace("Exit fetchProductByName method.");
		return productList;
	}

	public void updateTheProductQuantity(Product product, int quantity) throws ShoppingCartException {
		LOGGER.info("Update product quantity");
		try {
			productDao.updateQuantity(product.getProductId(), product.getQuantity() - quantity);
		} catch (Exception e) {
			LOGGER.error("Quantity could not be updated");
			throw new ShoppingCartException("Quantity could not be updated");
		}
	}
}
