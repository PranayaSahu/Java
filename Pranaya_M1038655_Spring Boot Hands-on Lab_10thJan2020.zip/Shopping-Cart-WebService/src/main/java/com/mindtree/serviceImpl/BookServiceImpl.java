package com.mindtree.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.BookDao;
import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.Book;
import com.mindtree.service.BookService;

@Service
public class BookServiceImpl implements BookService{

	private static final Logger LOGGER = LoggerFactory.getLogger(BookServiceImpl.class);
	@Autowired
	private BookDao bookDao;
	
	
	public List<Object> fetchAllBooks() throws ShoppingCartException {
		LOGGER.trace("Enter fetchDataForBooks method.");
		List<Object> listOfBooks = new ArrayList<Object>();
		try {
			Iterable<Book> bookIterable = bookDao.findAll();
			for (Book book : bookIterable) {
				listOfBooks.add(book);
			}
		} catch (Exception e) {
			LOGGER.error("Unable to fetch the books");
			throw new ShoppingCartException("Unable to fetch Books.");
		}
		LOGGER.trace("Exit fetchDataForBooks method.");
		return listOfBooks;
	}
}
