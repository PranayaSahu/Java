package com.mindtree.serviceImpl;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.UserDao;
import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.User;
import com.mindtree.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
	@Autowired
	private UserDao userDao;
	public int checkIfUserAlreadyPresent(String email, String password) throws ShoppingCartException {
		LOGGER.trace("Enter CheckIfUserAlreadyPresent method");
		int result = -1;
		try {
			Optional<User> u = userDao.findById(email);
			if (u.isPresent() && u.get().getPassword().equalsIgnoreCase(password)) {
				LOGGER.debug("Username and Password Matched.");
				result = 1;
			} 
			else if (!u.isPresent()) {
				LOGGER.debug("User not present.");
				userDao.save(new User(password, email));
				result = 0;
			} 
		} 
		catch (Exception e) {
			LOGGER.error("Unable to fetch the user : " + email);
			throw new ShoppingCartException("Unable to fetch the user");
		}
		LOGGER.trace("Exit CheckIfUserAlreadyPresent method");
		return result;
	}
	public User fetchUserByEmail(String email) throws ShoppingCartException {
		LOGGER.trace("Enter fetchUserByEmail method");
		LOGGER.info("fetchUserByEmail : " + email);
		User user = null;
		try {
			Optional<User> userFromDB = userDao.findById(email);
			if (userFromDB != null && userFromDB.get() != null) {
				user = userFromDB.get();
			}
		}
		catch (Exception ex) {
			LOGGER.error("User not present in database" + ex);
			throw new ShoppingCartException("Invalid User");
		}
		LOGGER.trace("Exit fetchUserByEmail method");
		return user;
	}
}
