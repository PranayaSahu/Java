package com.mindtree.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.ApparelDao;
import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.Apparel;
import com.mindtree.service.ApparelService;

@Service
public class ApparelServiceImpl implements ApparelService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApparelServiceImpl.class);

	@Autowired
	private ApparelDao apparelDao;

	public List<Object> fetchAllApparel() throws ShoppingCartException {
		LOGGER.trace("Enter fetchAllApparel method.");
		List<Object> listOfApparels = new ArrayList<Object>();
		try {
			Iterable<Apparel> apparelIterable = apparelDao.findAll();
			for (Apparel apparel : apparelIterable) {
				listOfApparels.add(apparel);
			}
		} catch (Exception e) {
			LOGGER.error("Unable to fetch the Apparel");
			throw new ShoppingCartException("Unable to fetch the Apparel from Database");
		}
		LOGGER.trace("Exit fetchAllApparel method.");
		return listOfApparels;
	}
}
