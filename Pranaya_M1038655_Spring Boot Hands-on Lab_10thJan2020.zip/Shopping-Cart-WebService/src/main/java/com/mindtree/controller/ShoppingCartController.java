package com.mindtree.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.dto.ShowCartDetailsDTO;
import com.mindtree.exception.ShoppingCartException;
import com.mindtree.model.Product;
import com.mindtree.model.User;
import com.mindtree.serviceImpl.ApparelServiceImpl;
import com.mindtree.serviceImpl.BookServiceImpl;
import com.mindtree.serviceImpl.CartServiceImpl;
import com.mindtree.serviceImpl.ProductServiceImpl;
import com.mindtree.serviceImpl.UserServiceImpl;

@RestController
public class ShoppingCartController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ShoppingCartController.class);
	@Autowired
	private ProductServiceImpl productService;

	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private CartServiceImpl cartService;

	@Autowired
	private BookServiceImpl bookService;

	@Autowired
	private ApparelServiceImpl apparelService;

	private HttpSession sessionMain;

	@RequestMapping(value = "/shoppingcart")
	public String homePage() {
		return "Welcome to Shopping Cart Application.";
	}

	@RequestMapping(value = "shoppingcart/login")
	public String userLogin(@RequestParam("userEmail") String userEmail, @RequestParam("password") String password,
			HttpSession session) throws ShoppingCartException {
		String returnString = null;
		int result = userService.checkIfUserAlreadyPresent(userEmail, password);
		if (result == 1) {
			saveSession(session, userEmail);
			returnString = "User logged in successfully.";
			LOGGER.info("User logged in successfully.");
		} else if (result == 0) {
			returnString = "New user created. Kindly login again to continue.";
			LOGGER.info("New user created. Kindly login again to continue.");
		} else {
			returnString = "User details incorrect.";
			LOGGER.info("User details incorrect.");
		}
		return returnString;
	}

	@RequestMapping(value = "shoppingcart/search/searchProductById", method = RequestMethod.GET)
	public Object searchProductById(@RequestParam("productId") int productId) throws ShoppingCartException {
		return productService.fetchProductById(productId);
	}

	@RequestMapping(value = "shoppingcart/search/searchProductByName", method = RequestMethod.GET)
	public List<Product> searchProductByName(@RequestParam("productName") String productName)
			throws ShoppingCartException {
		return productService.fetchProductByName(productName);
	}

	@RequestMapping(value = "shoppingCart/search/searchProductByCategory", method = RequestMethod.GET)
	public List<Object> searchProductByCategory(@RequestParam("productCategory") String productCategory)
			throws ShoppingCartException {
		List<Object> product = null;
		if (productCategory.equalsIgnoreCase("Book")) {
			product = bookService.fetchAllBooks();
		} else if (productCategory.equalsIgnoreCase("Apparel")) {
			product = apparelService.fetchAllApparel();
		}
		return product;
	}

	@RequestMapping(value = "/shoppingcart/addToCart", method = RequestMethod.POST)
	public String addProductToCart(@RequestParam("productId") int productId, @RequestParam("quantity") int quantity,
			HttpServletRequest request) throws ShoppingCartException {
		LOGGER.info("Adding Product to cart");
		String userEmail = null;
		if(sessionMain !=null) {
			userEmail = (String) sessionMain.getAttribute("userEmail");
		}
		if (userEmail != null) {
			LOGGER.info("Logged user is  : " + userEmail);
			User loggedUser = userService.fetchUserByEmail(userEmail);
			Product product = productService.fetchProductById(productId);
			List<Product> listOfProduct = new ArrayList<Product>();
			if (quantity < 0) {
				return "Quantity is invalid";
			}
			if (product.getQuantity() < quantity) {
				return "Product Stock not Available";
			}
			listOfProduct.add(product);
			if (loggedUser != null && !listOfProduct.isEmpty()) {
				boolean savedProd = cartService.addToCart(listOfProduct, loggedUser, quantity);
				if (savedProd) {
					productService.updateTheProductQuantity(product, quantity);
				}
				LOGGER.info("Product added successfully");
				return "Product Added in the cart.";
			}
			LOGGER.info("Products not added in the cart");
			return "Product not added in the cart";
		} else {
			LOGGER.info("User session is invalid. Please login to continue");
			return "User session is invalid. Please login to continue";
		}
	}

	@RequestMapping(value = "/shoppingcart/showCartDetails", method = RequestMethod.GET)
	public ShowCartDetailsDTO showCartDetails(@RequestParam("userEmail") String userEmail)
			throws ShoppingCartException {
		ShowCartDetailsDTO showDetails = new ShowCartDetailsDTO();
		String email = null;
		if(sessionMain !=null) {
			email = (String) sessionMain.getAttribute("userEmail");
		}
		if (email != null && userEmail.equalsIgnoreCase(email)) {
			LOGGER.info("In showCartDetails Method.");
			showDetails = cartService.viewCart(userEmail);
			if (showDetails != null) {
				return showDetails;
			} else {
				LOGGER.info("Cart is empty");
			}
		}
		LOGGER.info("Kindly login with the same user email to view the cart details");
		return null;
	}

	@RequestMapping(value = "/shoppingcart/removeProduct", method = RequestMethod.POST)
	public String removeProductById(@RequestParam("productId") int productId) throws ShoppingCartException {
		LOGGER.info("removeProductById");
		String userName = null;
		if(sessionMain !=null) {
			userName = (String) sessionMain.getAttribute("userEmail");
		}
		Product product = productService.fetchProductById(productId);
		if (product != null) {
			cartService.removeProductFromCart(productId, userName);
			return "Given Product was removed successfully";
		}
		return "Given Product could not be deleted";
	}

	@RequestMapping(value = "/shoppingcart/removeAllProducts", method = RequestMethod.POST)
	public String removeAllProductsFromCart(@RequestParam("userEmail") String email) throws ShoppingCartException {
		LOGGER.info("removeAllProductsFromCart");
		User user = userService.fetchUserByEmail(email);
		if (user != null) {
			cartService.removeAllProductsFromCart(user.getEmailAddress());
			return "All Product removed successfully";
		}
		return "Products could not be deleted";
	}

	private void saveSession(HttpSession session, String userEmail) {
		session.setAttribute("userEmail", userEmail);
		sessionMain = session;
	}
}
