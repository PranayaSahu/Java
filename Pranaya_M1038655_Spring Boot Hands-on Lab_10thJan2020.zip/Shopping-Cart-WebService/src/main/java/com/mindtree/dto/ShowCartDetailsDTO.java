package com.mindtree.dto;

import java.util.List;

import com.mindtree.model.Product;

public class ShowCartDetailsDTO {

	private List<Product> listOfProducts;
	
	private String userEmail;
	private double totalAmountDue;

	public List<Product> getListOfProducts() {
		return listOfProducts;
	}
	public void setListOfProducts(List<Product> listOfProducts) {
		this.listOfProducts = listOfProducts;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public double getTotalAmountDue() {
		return totalAmountDue;
	}
	public void setTotalAmountDue(double totalAmountDue) {
		this.totalAmountDue = totalAmountDue;
	}
	
	
}
