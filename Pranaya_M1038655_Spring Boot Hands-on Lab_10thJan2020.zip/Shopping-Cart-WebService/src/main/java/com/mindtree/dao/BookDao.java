package com.mindtree.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.model.Book;

@Transactional
public interface BookDao extends JpaRepository<Book, Integer>{

}
