package com.mindtree.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mindtree.model.Cart;
import com.mindtree.model.Product;

@Transactional
public interface CartDao extends JpaRepository<Cart, Integer> {

	@Query(value ="SELECT * from cart  where user_email_address=:email" ,nativeQuery = true)
	public Cart findCartDetailsByEmail(@Param("email")String userEmail);
	
	@Transactional
	@Modifying
	@Query(value = "INSERT into cart_products (cart_cart_id ,products_product_id) values(:c,:p)", nativeQuery = true)
	public void saveCartDetails(@Param("c") int c,@Param("p") List<Product> products);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE cart set products = :lop, total_price = :price where user_email_address=:email", nativeQuery = true)
	public void updateCartDetails(@Param("lop") List<Product> lop, @Param("email") String email, @Param("price") double price);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE cart set total_price = :price where user_email_address=:email", nativeQuery = true)
	public void updatePriceInCart(@Param("price") double price, @Param("email") String email);
	
	
	
}
