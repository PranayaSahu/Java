package com.mindtree.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.model.User;

@Transactional
public interface UserDao extends JpaRepository<User, String>{

}
