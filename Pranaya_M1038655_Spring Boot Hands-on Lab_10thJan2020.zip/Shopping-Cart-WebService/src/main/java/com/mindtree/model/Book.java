package com.mindtree.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("Book")
public class Book extends Product {

	public Book(int productId, String productName, float productPrice) {
		super(productId, productName, productPrice);
	}

	/**
	 * genre.
	 */
	private String bookGenre;
	/**
	 * author.
	 */
	private String bookAuthor;
	/**
	 * publications.
	 */
	private String bookPublications;

	public Book(int productId, String productName, double productPrice, int quantity, String bookGenre,
			String bookAuthor, String bookPublications) {
		super(productId, productName, productPrice, quantity);
		this.bookGenre = bookGenre;
		this.bookAuthor = bookAuthor;
		this.bookPublications = bookPublications;
	}

	public String getBookGenre() {
		return bookGenre;
	}

	public void setBookGenre(String bookGenre) {
		this.bookGenre = bookGenre;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getBookPublications() {
		return bookPublications;
	}

	public void setBookPublications(String bookPublications) {
		this.bookPublications = bookPublications;
	}

	public Book(int productId, String productName, double productPrice) {
		super(productId, productName, productPrice);
	}

	public Book() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((bookAuthor == null) ? 0 : bookAuthor.hashCode());
		result = prime * result + ((bookGenre == null) ? 0 : bookGenre.hashCode());
		result = prime * result + ((bookPublications == null) ? 0 : bookPublications.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (bookAuthor == null) {
			if (other.bookAuthor != null)
				return false;
		} else if (!bookAuthor.equals(other.bookAuthor))
			return false;
		if (bookGenre == null) {
			if (other.bookGenre != null)
				return false;
		} else if (!bookGenre.equals(other.bookGenre))
			return false;
		if (bookPublications == null) {
			if (other.bookPublications != null)
				return false;
		} else if (!bookPublications.equals(other.bookPublications))
			return false;
		return true;
	}

}
