package com.mindtree.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User implements Comparable<User> {

	/**
	 * password.
	 */
	private String password;
	/**
	 * emailAddress.
	 */
	@Id
	private String emailAddress;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public User(String password, String emailAddress) {
		super();
		this.password = password;
		this.emailAddress = emailAddress;
	}

	public User() {

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((emailAddress == null) ? 0 : emailAddress.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (emailAddress == null) {
			if (other.emailAddress != null)
				return false;
		} else if (!emailAddress.equals(other.emailAddress))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	public int compareTo(User userObj) {
		if (emailAddress != null && userObj.getEmailAddress() != null) {
			return emailAddress.compareTo(userObj.getEmailAddress());
		}
		return 0;
	}

}
