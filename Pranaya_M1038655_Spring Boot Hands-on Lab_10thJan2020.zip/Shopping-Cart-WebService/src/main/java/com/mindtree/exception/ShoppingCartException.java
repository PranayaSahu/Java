package com.mindtree.exception;

public class ShoppingCartException extends Exception{

	private static final long serialVersionUID = 1L;

	public ShoppingCartException(String exp) {
		super(exp);
	}
}
